#!/bin/bash
# This is to ensure docker-compose.yml is in place
cd /home/ec2-user/app
