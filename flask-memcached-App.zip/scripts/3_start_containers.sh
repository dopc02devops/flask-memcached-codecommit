#!/bin/bash
cd /home/ec2-user/app
docker-compose up -d
