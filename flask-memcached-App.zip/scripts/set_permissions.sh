#!/bin/bash
# Set execution permission for all `.sh` files in the 'scripts' directory.
chmod +x /home/kube_user/scripts/*.sh
